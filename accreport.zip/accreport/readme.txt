


Configuration Details:
-----------------------

OS : linux (redhat 7 or Centos 7)
Webserver : apache
Backend   : mysql-server / mariadb-server
python    : python3.6+


Installation
--------------
#yum install  python36 MySQL-python36 mysql-connector-python mysql-connector-python36 httpd  

#cp -r  acc  /var/www/html
#cp -r  cgi/*   /var/www/cgi-bin
#chmod 755 /var/www/cgi-bin/*

#systemctl restart mariadb
#systemctl enable mariadb
#mysql_secure_installation
set password for root user : redhat
then execute until finish.

#mysql -u root -p
password:redhat

> create database accreport;
> use accreport;

copy all data from accreport.sql   and paste here then execute

>show tables;

>exit;

#systemctl restart httpd
#systemctl enable httpd
#systemctl stop firewalld   ( optional )
#setenforce 0  		    ( optional )

open link

http://yourip/acc

------------------------------------------------
Thank You - Team Appin-Cloud Computing BATCH-3.30PM





















   










 
