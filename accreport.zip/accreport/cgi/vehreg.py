#!/usr/bin/python3

import MySQLdb
import cgi,cgitb


db = MySQLdb.connect("localhost","root","redhat","accreport")
cu = db.cursor()

form = cgi.FieldStorage()

print("Content-type:text/html \n\n")

x = form.getvalue('np')
y = []
for i in range(int(x)):
	y.append([form.getvalue('vnum'+str(i)),form.getvalue('vowner'+str(i)), form.getvalue('rto'+str(i)),form.getvalue('mob'+str(i)), form.getvalue('nowner'+str(i)),form.getvalue('vmodel'+str(i)),form.getvalue('fid'+str(i))])

try:
	for i in range(int(x)):
		cu.execute("insert into veh_details (veh_num,veh_owner,rto,owner_mob,no_of_own,veh_model_color,fir_id) values ('%s','%s','%s','%s','%s','%s','%s')" %(y[i][0],y[i][1],y[i][2],y[i][3],y[i][4],y[i][5],y[i][6]))
		db.commit();
		print(" <script> alert('data inserted'); </script>")
except:
	print(" <script> alert('data insertion failed');location.href='/acc/vehical.html'; </script>")








