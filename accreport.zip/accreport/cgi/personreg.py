#!/usr/bin/python3

import MySQLdb
import cgi,cgitb


db = MySQLdb.connect("localhost","root","redhat","accreport")
cu = db.cursor()

form = cgi.FieldStorage()

print("Content-type:text/html \n\n")

x = form.getvalue('np')
y = []
for i in range(int(x)):
	y.append([form.getvalue('name'+str(i)),form.getvalue('age'+str(i)), form.getvalue('gen'+str(i)),form.getvalue('add'+str(i)), form.getvalue('mob'+str(i)),form.getvalue('hos'+str(i)),form.getvalue('fid'+str(i))])

try:
	for i in range(int(x)):
		cu.execute("insert into person_details (p_name,p_age,p_gen,p_add,p_mob,hospital,fir_id) values ('%s','%s','%s','%s','%s','%s','%s')" %(y[i][0],y[i][1],y[i][2],y[i][3],y[i][4],y[i][5],y[i][6]))
		db.commit();
		print(" <script> alert('data inserted');location.href='/acc/vehical.html'; </script>")
except:
	print(" <script> alert('data insertion failed');location.href='/acc/person.html'; </script>")








