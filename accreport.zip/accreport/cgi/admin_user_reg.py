#!/usr/bin/python3

import MySQLdb
import cgi,cgitb


db = MySQLdb.connect("localhost","root","redhat","accreport")
cu = db.cursor();

form = cgi.FieldStorage()

sn = form.getvalue('sname')
sc = form.getvalue('scode')
u1 = form.getvalue('uname')
p1 = form.getvalue('pass1')
r1 = form.getvalue('role1')
mob1 = form.getvalue('mob1')
email = form.getvalue('email1')


print("Content-type:text/html \n\n")

try:
	cu.execute("insert into admin(station_name,station_code,userid,password,phone,email,role ) values('%s','%s','%s','%s','%s','%s','%s')" %(sn,sc,u1,p1,mob1,email,r1))
	db.commit()
	print("<script> alert('User Registered');location.href='/acc/padmin.html'; </script>");
	
except:
	print("<script> alert('User Registration Failed');location.href='/acc/admin_user_reg.html'; </script>");





 
