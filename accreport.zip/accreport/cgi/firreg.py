#!/usr/bin/python3

import MySQLdb
import cgi,cgitb


db = MySQLdb.connect("localhost","root","redhat","accreport")
cu = db.cursor();

form = cgi.FieldStorage()

fn = form.getvalue('fnum')
st = form.getvalue('station')
acd= form.getvalue('adate')
act = form.getvalue('atime')
ade = form.getvalue('message')

print("Content-type:text/html \n\n")

try:
	cu.execute("insert into fir_details(fir_num,station,accdate,acctime,accdesc) values('%s','%s','%s','%s','%s')" %(fn,st,acd,act,ade))
	db.commit()
	print("<script> alert('FIR Registered'); </script>");
	cu.execute("select * from fir_details where fir_num='%s'" %(fn))
	re = cu.fetchall()
	print("<html><head><title>fir result</title></head>")
	print("<body bgcolor='MediumSeaGreen' text='white'>")
	print("<h2 align='center'> FIR DETAILS </h2>")
	print("<hr> <center>")
	print("<table cellspacing='20' bgcolor='black'>")
	print("<tr> <td> FIR id </td> <td> %s </td> </tr> " %re[0][0])
	print("<tr> <td> FIR Number </td> <td> %s </td> </tr>" %re[0][1])
	print("<tr> <td> Police Station </td> <td> %s </td> </tr>" %re[0][2])
	print("<tr> <td> Accident Date </td> <td> %s </td> </tr>" %re[0][3])
	print("<tr> <td> Accident Time </td> <td> %s </td> </tr>" %re[0][4])
	print("<tr> <td> Accident Details </td> <td> %s </td> </tr>" %re[0][5])
	print("</table></center>")
	print("""<input type='button' value='Next Page' onclick="location.href='/acc/person.html' " """)
	print("</body></html>")

except:
	print("<script> alert('FIR Registration Failed');location.href='/acc/fir.html'; </script>");





 
