#!/usr/bin/python3

import MySQLdb
import cgi,cgitb


db = MySQLdb.connect("localhost","root","redhat","accreport")
cu = db.cursor();

form = cgi.FieldStorage()

fn = form.getvalue('fname')
ln = form.getvalue('lname')
u1 = form.getvalue('uname')
p1 = form.getvalue('pass1')
dob1 = form.getvalue('dob1')
add1 = form.getvalue('add1')
mob1 = form.getvalue('mob1')
r1 = form.getvalue('role1')


print("Content-type:text/html \n\n")

try:
	cu.execute("insert into userid(fname,lname,username,password,dob,address,mobile,role) values('%s','%s','%s','%s','%s','%s','%s','%s')" %(fn,ln,u1,p1,dob1,add1,mob1,r1))
	db.commit()
	print("<script> alert('Police User Registered');location.href='/acc/police.html'; </script>");
	
except:
	print("<script> alert('User Registration Failed');location.href='/acc/policereg.html'; </script>");





 
