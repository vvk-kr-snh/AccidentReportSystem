#!/usr/bin/python3

import MySQLdb
import cgi,cgitb


db = MySQLdb.connect("localhost","root","redhat","accreport")
cu = db.cursor();

form = cgi.FieldStorage()

u = form.getvalue('uname')
p = form.getvalue('pass1')
r = form.getvalue('role1')


print("Content-type:text/html \n\n")

try:
	cu.execute("select password,role from userid where username='%s' and role='%s'" %(u,r))
	re  = cu.fetchone()
	if re[0]==p and re[1]=='user':
		print("<script> alert('Welcome to Accident Vehicle Search');location.href='/acc/search.html'; </script>");
	elif re[0]==p and re[1]=='police':
		print("<script> alert('Welcome to Vehicle Accident Lookup');location.href='/acc/police.html'; </script>");
	else:
		print("<script> alert('Invalid Password or Role');location.href='/acc/index.html'; </script>");

except:
	print("<script> alert('Please Enter Correct User Name');location.href='/acc/index.html'; </script>");





 
