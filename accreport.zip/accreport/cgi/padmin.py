#!/usr/bin/python3

import MySQLdb
import cgi,cgitb


db = MySQLdb.connect("localhost","root","redhat","accreport")
cu = db.cursor();

form = cgi.FieldStorage()

u = form.getvalue('uname')
p = form.getvalue('pass1')
r = form.getvalue('role1')


print("Content-type:text/html \n\n")

try:
	cu.execute("select password,role from admin where userid='%s'" %(u))
	re  = cu.fetchone()
	if re[0]==p and r==re[1] and re[1]=='station':
		print("<script> alert('Welcome to ARS');location.href='/acc/fir.html'; </script>");
	elif re[0]==p and r==re[1] and re[1]=='admin':
		print("<script> alert('Welcome to ARS-ADMIN');location.href='/acc/admin_main.html'; </script>");
	else:
		print("<script> alert('Invalid Password or Role');location.href='/acc/padmin.html'; </script>");

except:
	print("<script> alert('Please Enter Correct User Name');location.href='/acc/padmin.html'; </script>");





 
