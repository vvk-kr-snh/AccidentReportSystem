#!/usr/bin/python3

import MySQLdb
import cgi,cgitb


db = MySQLdb.connect("localhost","root","redhat","accreport")
cu = db.cursor();

form = cgi.FieldStorage()

vn = form.getvalue('vnum')


print("Content-type:text/html \n\n")

try:
	cu.execute("select veh_num,veh_owner,rto,fir_num,station,accdate  from veh_details,fir_details where veh_num='%s' and veh_details.fir_id=fir_details.fid;" %(vn) )
	re  = cu.fetchone()
	if re[0]==vn:
		print("""
		<html>
		<head><title> Result Page </title></head>
		<body bgcolor='MediumSeaGreen' text='white'>
		<h1 align='center'> Vehicle Record </h1><hr>
		<center>
		<h3 align='center'> Below Given Vehical is Accident Reported. </h3>
		<table cellspacing='20' bgcolor='seagreen'>
		<tr> <td> Vehicle Number </td> <td> : %s </td></tr>
		<tr> <td> Owner Name </td> <td> : %s </td></tr>
		<tr> <td> RTO </td> <td> : %s </td></tr>
		<tr> <td> FIR Number </td> <td> : %s </td></tr>
		<tr> <td> Station </td> <td> : %s </td></tr>
		<tr> <td> Accident Date </td> <td> : %s </td></tr>
		</table>
		<input type='button' value='Print' onclick='window.print()'>
		<input type='button' value='Back' onclick="location.href='/acc/search.html'">
		</body>
		</html> """ %(re[0],re[1],re[2],re[3],re[4],re[5]))
		


	else:
		print("<script> alert('Vehicle Not Found');location.href='/acc/search.html'; </script>");

except:
	print("<script> alert('Vehicle Not Found');location.href='/acc/search.html'; </script>");





 
