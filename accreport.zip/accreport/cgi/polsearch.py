#!/usr/bin/python3

import MySQLdb
import cgi,cgitb


db = MySQLdb.connect("localhost","root","redhat","accreport")
cu = db.cursor();

form = cgi.FieldStorage()

vn = form.getvalue('vnum')



print("Content-type:text/html \n\n")

try:
	cu.execute("select * from veh_details where veh_num='%s'" %(vn))
	re  = cu.fetchone()


	if re[1]==vn:
		cu.execute("select * from person_details where fir_id='%s'" %re[7] )
		re1  = cu.fetchall()

		cu.execute("select * from fir_details where fid='%s'" %re[7] )
		fr  = cu.fetchone()


		print("""
		<html>
		<head><title> Result Page </title></head>
		<body bgcolor='MediumSeaGreen' text='white'>

		<fieldset>
		<legend>Vehical Details</legend>
		<center>
		<h3 align='center'> Below Given Vehical is Accident Reported. </h3>
		<table cellspacing='20' bgcolor='seagreen' width='800'>
		<tr> <td> Vehicle Number </td> <td> : %s </td></tr>
		<tr> <td> Owner Name </td> <td> : %s </td></tr>
		<tr> <td> RTO </td> <td> : %s </td></tr>
		<tr> <td> Owner Mobile </td> <td> : %s </td></tr>
		<tr> <td> Owner Ship Status </td> <td> : %s </td></tr>
		<tr> <td> Vehical Model and Color </td> <td> : %s </td></tr>
		</table></center>
		</fieldset>""" %(re[1],re[2],re[3],re[4],re[5],re[6]))
		
		j=0
		while(j<len(re1)):
			print("""<fieldset>
			<legend>Person Details - %s </legend>
			<center>
			<h3 align='center'> Person Associate with Vehicle Number %s </h3>
			<table cellspacing='20' bgcolor='seagreen' width='800'>
			<tr> <td> Name  </td> <td> : %s </td></tr>
			<tr> <td> Age </td> <td> : %s </td></tr>
			<tr> <td> Gender </td> <td> : %s </td></tr>
			<tr> <td> Address </td> <td> : %s </td></tr>
			<tr> <td> Mobile </td> <td> : %s </td></tr>
			<tr> <td> Hospital </td> <td> : %s </td></tr>
			</table></center>
			</fieldset>""" %(j+1,re[1],re1[j][1],re1[j][2],re1[j][3],re1[j][4],re1[j][5],re1[j][6]))
			j+=1

		print("""<fieldset>
		<legend>Fir Details</legend>
		<center>
		<h3 align='center'> Below Given is the FIR Details of above mentioned Vehical and Person. </h3>
		<table cellspacing='20' bgcolor='seagreen' width='800'>
		<tr> <td> FIR Number </td> <td> : %s </td></tr>
		<tr> <td> Police Station </td> <td> : %s </td></tr>
		<tr> <td> Accident Date </td> <td> : %s </td></tr>
		<tr> <td> Accident Time </td> <td> : %s </td></tr>
		<tr> <td> Accident Description </td> <td> : %s </td></tr>
		""" %(fr[1],fr[2],fr[3],fr[4],fr[5]))

		cu.execute("select veh_num from veh_details where fir_id='%s'" %(re[7]))
		d1 = cu.fetchall()
		k=0
		while(k<len(d1)):
			print("""<tr> <td> Vehical - %s </td> <td> : %s </td></tr>
			""" %(k+1,d1[k][0]))
			k+=1
		
		cu.execute("select p_name from person_details where fir_id='%s'" %(re[7]))
		p1 = cu.fetchall()
		m=0
		while(m<len(p1)):
			print(""" <tr><td>Person Name - %s: </td> <td>: %s </td></tr> """ %(m+1,p1[m][0]))
			m+=1
		



		print("""
		</table></center>
		</fieldset>
		<input type='button' value='Print' onclick='window.print()'>
		<input type='button' value='Back' onclick="location.href='/acc/police.html'">
		</body>
		</html> """)
		
		

	else:
		print("<script> alert('Vehicle Not Found');location.href='/acc/police.html'; </script>");

except:
	print("<script> alert('Vehicle Not Found');location.href='/acc/police.html'; </script>");




 
