-- MySQL dump 10.14  Distrib 5.5.60-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: accreport
-- ------------------------------------------------------
-- Server version	5.5.60-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `station_name` varchar(60) DEFAULT NULL,
  `station_code` varchar(20) DEFAULT NULL,
  `userid` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `role` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB AUTO_INCREMENT=1115 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1111,'admin','admin','accadmin','redhat','8282828208','accadmin@gmail.com','admin'),(1112,'TT Nagar','MP/BPL/TTNAGAR/01','ttnagar01','123','8282828587','ttnagar_thana@gmail.com','station'),(1114,'aishbag','MP/BPL/AISHBAG/01','aishbag01','123456','8385847284','aishbagthana.bhopal@gmail.com','station');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fir_details`
--

DROP TABLE IF EXISTS `fir_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fir_details` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fir_num` varchar(50) DEFAULT NULL,
  `station` varchar(60) DEFAULT NULL,
  `accdate` varchar(20) DEFAULT NULL,
  `acctime` varchar(20) DEFAULT NULL,
  `accdesc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fir_details`
--

LOCK TABLES `fir_details` WRITE;
/*!40000 ALTER TABLE `fir_details` DISABLE KEYS */;
INSERT INTO `fir_details` VALUES (101,'mp-2019-206','mp nagar','2019-07-04','03:30PM','tvs jupiter collided with activa no major casuality'),(102,'mp-2019-209','bag sewaniya','2019-06-03','22:07','\r\nnoting ');
/*!40000 ALTER TABLE `fir_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person_details`
--

DROP TABLE IF EXISTS `person_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `person_details` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `p_name` varchar(200) DEFAULT NULL,
  `p_age` varchar(20) DEFAULT NULL,
  `p_gen` varchar(20) DEFAULT NULL,
  `p_add` varchar(200) DEFAULT NULL,
  `p_mob` varchar(20) DEFAULT NULL,
  `hospital` varchar(200) DEFAULT NULL,
  `fir_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`pid`),
  KEY `fir_id` (`fir_id`),
  CONSTRAINT `person_details_ibfk_1` FOREIGN KEY (`fir_id`) REFERENCES `fir_details` (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person_details`
--

LOCK TABLES `person_details` WRITE;
/*!40000 ALTER TABLE `person_details` DISABLE KEYS */;
INSERT INTO `person_details` VALUES (10,'Anil Kumar','25','male','16/7 saket nagar bhoapl','9868986898','narmada truma center',101),(11,'vivek kumar','24','male','mp nagar','9898989898','Bansal hospital',102),(12,'tarun kumar','25','male','new market','7878787878','Bhopal Fracture',102);
/*!40000 ALTER TABLE `person_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userid`
--

DROP TABLE IF EXISTS `userid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userid` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(60) DEFAULT NULL,
  `lname` varchar(60) DEFAULT NULL,
  `username` varchar(60) DEFAULT NULL,
  `password` varchar(60) DEFAULT NULL,
  `dob` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=207 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userid`
--

LOCK TABLES `userid` WRITE;
/*!40000 ALTER TABLE `userid` DISABLE KEYS */;
INSERT INTO `userid` VALUES (201,'sam','mehra','sam123','123456','1996-02-25','mp nagar bhopal','8687484848','user'),(203,'anil','jain','anil123','123456','1993-05-11','mp nagar bhopal','8574857485','user'),(204,'neha','jain','neha123','123456','1994-07-12','mp nagar bhopal','8586895858','user'),(205,'Natasha','raghuwanshi','nat@rathish','rathish','1998-07-05','mpnagar','123456789','user'),(206,'vinil','pandey','vinil123','123456','1987-05-20','mp nagar bhopal','8989896767','police');
/*!40000 ALTER TABLE `userid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `veh_details`
--

DROP TABLE IF EXISTS `veh_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `veh_details` (
  `vid` int(11) NOT NULL AUTO_INCREMENT,
  `veh_num` varchar(50) DEFAULT NULL,
  `veh_owner` varchar(100) DEFAULT NULL,
  `rto` varchar(60) DEFAULT NULL,
  `owner_mob` varchar(20) DEFAULT NULL,
  `no_of_own` varchar(20) DEFAULT NULL,
  `veh_model_color` varchar(200) DEFAULT NULL,
  `fir_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`vid`),
  KEY `fir_id` (`fir_id`),
  CONSTRAINT `veh_details_ibfk_1` FOREIGN KEY (`fir_id`) REFERENCES `fir_details` (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=1003 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `veh_details`
--

LOCK TABLES `veh_details` WRITE;
/*!40000 ALTER TABLE `veh_details` DISABLE KEYS */;
INSERT INTO `veh_details` VALUES (1001,'mp04mg9654','sam sharma','bhopal','8575485748','1','tvs-jupiter-white',101),(1002,'mp04mg8584','mukesh kumar','bhopal','9898965654','1','bajaj pulsur 180-black',102);
/*!40000 ALTER TABLE `veh_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-09 16:16:31
